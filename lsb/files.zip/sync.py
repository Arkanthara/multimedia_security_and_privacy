"""
utils/sync.py
=============
Frequency-domain synchronisation for LSB watermark decoding.

Pipeline
--------
1. Log-polar phase correlation  → estimate rotation + scale
2. Correct rotation / scale     → cropped (no resize artefacts)
3. Cartesian phase correlation  → estimate translation
4. Correct translation          → final aligned image
"""

import numpy as np
from skimage.transform import warp, AffineTransform
from skimage.registration import phase_cross_correlation
from skimage.util import img_as_float64
from skimage.transform import warp_polar


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _autocorr_spectrum(image: np.ndarray) -> np.ndarray:
    """
    Compute the power spectrum (|FFT|²) of *image*, used as a
    rotation/scale-invariant representation.

    Parameters
    ----------
    image : ndarray of shape (H, W), real-valued

    Returns
    -------
    spectrum : ndarray of shape (H, W), dtype float64
        Log-scaled magnitude spectrum, shifted so DC is at centre.
    """
    f      = np.fft.fft2(image)
    power  = np.abs(np.fft.fftshift(f)) ** 2
    # Log scale compresses dynamic range → better phase correlation
    return np.log1p(power)


def _to_log_polar(spectrum: np.ndarray) -> np.ndarray:
    """
    Convert a centred power spectrum to log-polar coordinates.

    Parameters
    ----------
    spectrum : ndarray of shape (H, W)

    Returns
    -------
    log_polar : ndarray of shape (H, W)
    """
    return warp_polar(spectrum, scaling="log")


# ---------------------------------------------------------------------------
# Rotation + scale estimation
# ---------------------------------------------------------------------------

def estimate_rotation_scale(
    lsb_image: np.ndarray,
    reference: np.ndarray,
) -> tuple[float, float]:
    """
    Estimate rotation (degrees) and scale factor between *lsb_image*
    and *reference* using log-polar phase correlation.

    Parameters
    ----------
    lsb_image : ndarray of shape (H, W), uint8
        LSB plane extracted from the watermarked image.
    reference : ndarray of shape (H, W), uint8
        Reference patch tiled to the same size.

    Returns
    -------
    angle : float
        Estimated rotation angle in degrees.
    scale : float
        Estimated scale factor (> 1 means image was zoomed in).
    """
    img_f  = img_as_float64(lsb_image)
    ref_f  = img_as_float64(reference)

    img_lp = _to_log_polar(_autocorr_spectrum(img_f))
    ref_lp = _to_log_polar(_autocorr_spectrum(ref_f))

    shift, _, _ = phase_cross_correlation(ref_lp, img_lp, normalization=None)

    H, W  = img_lp.shape
    angle = (shift[0] / H) * 360.0          # rows → degrees
    scale = 10 ** (shift[1] / (W / np.log(max(H, W) / 2)))  # cols → scale
    return float(angle), float(scale)


# ---------------------------------------------------------------------------
# Rotation + scale correction
# ---------------------------------------------------------------------------

def correct_rotation_scale(
    image: np.ndarray,
    angle: float,
    scale: float,
) -> np.ndarray:
    """
    Apply inverse rotation and scale to *image*.

    The image is cropped to its original size — no resize artefacts.

    Parameters
    ----------
    image : ndarray of shape (H, W)
    angle : float
        Rotation angle in degrees (as returned by
        :func:`estimate_rotation_scale`).
    scale : float
        Scale factor.

    Returns
    -------
    corrected : ndarray of shape (H, W), dtype uint8
    """
    H, W = image.shape
    cx, cy = W / 2.0, H / 2.0

    # Build inverse transform: undo rotation and scale
    tform = (
        AffineTransform(translation=(-cx, -cy))
        + AffineTransform(rotation=np.deg2rad(angle), scale=(scale, scale))
        + AffineTransform(translation=(cx, cy))
    )

    corrected = warp(
        img_as_float64(image),
        tform.inverse,
        preserve_range=True,
        order=1,
        mode="edge",
    )
    return np.clip(np.round(corrected), 0, 1).astype(np.uint8)


# ---------------------------------------------------------------------------
# Translation estimation + correction
# ---------------------------------------------------------------------------

def estimate_translation(
    lsb_image: np.ndarray,
    reference: np.ndarray,
) -> tuple[int, int]:
    """
    Estimate integer pixel translation via Cartesian phase correlation.

    Parameters
    ----------
    lsb_image : ndarray of shape (H, W)
    reference : ndarray of shape (H, W)

    Returns
    -------
    shift_row : int
    shift_col : int
    """
    shift, _, _ = phase_cross_correlation(
        img_as_float64(reference),
        img_as_float64(lsb_image),
        normalization=None,
    )
    return int(round(shift[0])), int(round(shift[1]))


def correct_translation(
    image: np.ndarray,
    shift_row: int,
    shift_col: int,
) -> np.ndarray:
    """
    Shift *image* by (-shift_row, -shift_col), wrapping with ``np.roll``.

    Parameters
    ----------
    image : ndarray of shape (H, W)
    shift_row : int
    shift_col : int

    Returns
    -------
    shifted : ndarray of shape (H, W), same dtype
    """
    return np.roll(image, (-shift_row, -shift_col), axis=(0, 1))


# ---------------------------------------------------------------------------
# Full synchronisation pipeline
# ---------------------------------------------------------------------------

def synchronise(
    lsb_image: np.ndarray,
    reference: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Align *lsb_image* to *reference* using a two-stage pipeline:

    1. Log-polar phase correlation → rotation + scale correction.
    2. Cartesian phase correlation → translation correction.

    Parameters
    ----------
    lsb_image : ndarray of shape (H, W), uint8
    reference : ndarray of shape (H, W), uint8
        Reference patch (same size as *lsb_image*).

    Returns
    -------
    aligned_lsb : ndarray of shape (H, W), uint8
        LSB plane realigned to the reference patch grid.
    aligned_reference : ndarray of shape (H, W), uint8
        Reference regenerated at the corrected size (same as input size
        after crop — always equals *reference* since we crop, not resize).
    """
    # Stage 1 — rotation + scale
    angle, scale = estimate_rotation_scale(lsb_image, reference)
    lsb_rs       = correct_rotation_scale(lsb_image, angle, scale)

    # Stage 2 — translation
    dr, dc    = estimate_translation(lsb_rs, reference)
    lsb_final = correct_translation(lsb_rs, dr, dc)

    return lsb_final, reference
